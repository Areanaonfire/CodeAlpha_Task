# password_storage.py
import bcrypt

def store_password(password):
    hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
    # Store 'hashed' in the database instead of the password
    print("Password stored successfully!")

def check_password(stored_hash, password):
    if bcrypt.checkpw(password.encode('utf-8'), stored_hash):
        print("Password is correct")
    else:
        print("Incorrect password")
