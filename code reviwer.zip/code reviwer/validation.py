# validation.py
def validate_input(username, password):
    if len(username) > 0 and len(password) > 0:
        print("Input is valid.")
        return True
    else:
        print("Input is invalid.")
        return False
