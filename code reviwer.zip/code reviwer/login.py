# login.py
def login(username, password):
    print(f"Attempting to log in with {username}")
    # Add your login logic here (e.g., check against stored data)
    if username == "testuser" and password == "password123":
        print("Login successful!")
    else:
        print("Login failed!")
