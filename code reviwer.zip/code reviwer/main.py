print("Starting the script...")

from login import login
from password_storage import store_password, check_password
from validation import validate_input

# Example usage
username = "testuser"
password = "password123"

if validate_input(username, password):
    login(username, password)
else:
    print("Invalid input!")

print("Script ended.")
