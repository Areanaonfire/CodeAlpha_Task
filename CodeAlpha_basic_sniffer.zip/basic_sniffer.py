import socket

def basic_sniffer():
    try:
        # Create a raw socket
        sniffer = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_IP)
        
        # Bind to the local IP address (use actual IP, not 127.0.0.1)
        HOST = "192.168.230.1"  # Replace with your local machine's IP
        sniffer.bind((HOST, 0))

        # Include IP headers in the capture
        sniffer.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)

        # Enable promiscuous mode on Windows
        sniffer.ioctl(socket.SIO_RCVALL, socket.RCVALL_ON)

        print(f"Sniffer started on {HOST}. Listening for packets...")
        while True:
            # Receive a single packet
            raw_packet, addr = sniffer.recvfrom(65565)
            print(f"Packet from {addr}: {raw_packet}")
    except KeyboardInterrupt:
        print("\nStopping sniffer.")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        # Disable promiscuous mode before exiting
        sniffer.ioctl(socket.SIO_RCVALL, socket.RCVALL_OFF)
        print("Sniffer stopped.")

if __name__ == "__main__":
    basic_sniffer()
